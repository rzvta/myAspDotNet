﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace hcbl
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnreg_Click(object sender, EventArgs e)
        {
            
            if (TextBox5.Text != txtpassword.Text)
            {
                lblerror.Text = "Passwords do not match";
            }
            else
            {
                int flag = 0;
                SqlConnection con = new SqlConnection();
                con.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=c:\users\sasi.smart\documents\visual studio 2010\Projects\hcbl\hcbl\App_Data\registration.mdf;Integrated Security=True;User Instance=True";
                SqlCommand cmd1 = new SqlCommand("Validate_Service_id", con);
                cmd1.CommandType = CommandType.StoredProcedure;
                cmd1.Parameters.AddWithValue("@service_id", txtserviceid.Text);
                con.Open();
                flag = Convert.ToInt32(cmd1.ExecuteScalar());

                switch (flag)
                {
                    case -1: Label8.Text = "Service ID already Exists";
                        break;
                    case 1: string q = "insert into registerTB(service_id,firstname,lastname,email_id,password,choose_mnc,gender,dob,address,city,state,country,zip_code,phone,choose_plan,bank_name,branch_name,account_no,account_ho_name,uan,ifsc)" + "values('" + txtserviceid.Text + "','" + txtfirst.Text + "','" + txtlast.Text + "','" + txtemail.Text + "','" + txtpassword.Text + "','" + dropdwnmnc.SelectedItem.Value + "','" + DropDownList1.SelectedItem.Value + "','" + TextBox6.Text + "','" + TextBox7.Text + "','" + TextBox8.Text + "','" + DropDownList3.SelectedItem.Value + "','" + TextBox9.Text + "','" + TextBox10.Text + "','" + TextBox11.Text + "','" + dropdownplan.SelectedItem.Value + "','" + dropdownbname.SelectedItem.Value + "','" + txtbrnchnaame.Text + "','" + txtaccno.Text + "','" + txtacchoname.Text + "','" + txtuan.Text + "','" + txtifsc.Text + "')";
                        
                        SqlCommand cmd = new SqlCommand(q, con);
                        cmd.ExecuteNonQuery();
                        con.Close();
                        if (dropdownplan.SelectedItem.Value == "PF Account")
                        {
                            Response.Redirect("~/thanku.aspx");
                        }
                        else
                        {
                            Response.Redirect("~/deposit.aspx");
                        }
                
                        break;
                    
                }
                
                
            }
            
        }
    }
}