﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace hcbl
{
    public partial class WebForm19 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["hospital_id"] != null)
            {

                lblhosid.Text = Session["hospital_id"].ToString();

            }
            if (Session["Service_id"] != null)
            {

                lblservicevalue.Text = Session["service_id"].ToString();

            }

            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\sasi.smart\documents\visual studio 2010\Projects\hcbl\hcbl\App_Data\registration.mdf;Integrated Security=True;User Instance=True";
            con.Open();
            SqlCommand cmd1 = new SqlCommand("select service_id,choose_mnc,firstname,lastname,email_id,gender,dob,address,city,state,country,zip_code,phone,deposit_amount from registerTB where service_id=" + lblservicevalue.Text, con);
            SqlDataReader dr = cmd1.ExecuteReader();
            dr.Read();
            lblservicevalue.Text = dr.GetString(0);
            lblmncval.Text = dr.GetString(1);


            lblfnameval.Text = dr.GetString(2);

            lbllnameval.Text = dr.GetString(3);


            lblemailval.Text = dr.GetString(4);

            lblgenval.Text = dr.GetString(5);
            lbldobval.Text = dr.GetString(6);
            lbladdval.Text = dr.GetString(7);
            lblcityval.Text = dr.GetString(8);
            lblstateval.Text = dr.GetString(9);
            lblcountryval.Text = dr.GetString(10);
            lblzipval.Text = dr.GetString(11);
            lblphoneval.Text = dr.GetString(12);

            double val = Convert.ToInt32(dr.GetString(13));
            double cover = 1.1 * val;
            lblcoverval.Text = cover.ToString();
            con.Close();


        }

        protected void btn_rr_Click(object sender, EventArgs e)
        {
            if (Session["hospital_id"] != null)
            {

                lblhosid.Text = Session["hospital_id"].ToString();

            }
            if (Session["Service_id"] != null)
            {

                lblservicevalue.Text = Session["service_id"].ToString();

            }

            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\sasi.smart\documents\visual studio 2010\Projects\hcbl\hcbl\App_Data\registration.mdf;Integrated Security=True;User Instance=True";
            con.Open();
            SqlCommand cmd1 = new SqlCommand("insert into raise_request values(' " + lblhosid.Text + "','" + lblservicevalue.Text + "')", con);
            cmd1.ExecuteNonQuery();
            con.Close();
            Response.Redirect("raise_thanku.aspx");
        }
    }
}