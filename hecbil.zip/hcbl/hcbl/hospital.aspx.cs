﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace hcbl
{
    public partial class WebForm10 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
             if (lblid.Text.Trim() == string.Empty)
            {
                lblid.Text = "Please Input Hospital ID";
            }
             else if (lblpassword.Text.Trim() == string.Empty)
             {
                 lblpassword.Text = "Please Input Password";
             }
             else
             {
                 int flag = 0;
                 SqlConnection con = new SqlConnection();
                 con.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\sasi.smart\documents\visual studio 2010\Projects\hcbl\hcbl\App_Data\registration.mdf;Integrated Security=True;User Instance=True";
                 con.Open();
                 SqlCommand cmd = new SqlCommand("Validate_hospital", con);
                 cmd.CommandType = CommandType.StoredProcedure;
                 cmd.Parameters.AddWithValue("@hospital_id", lblid.Text);
                 cmd.Parameters.AddWithValue("@password", lblpassword.Text);



                 flag = Convert.ToInt32(cmd.ExecuteScalar());

                 con.Close();
                 switch (flag)
                 {
                     case 0: lblError.Text = "Hospital isnt registered";
                         break;
                     case 1: Session["hospital_id"] = lblid.Text;
                         Response.Redirect("hospital_home.aspx");
                         break;
                     

                 }

             }
        }
    }
}