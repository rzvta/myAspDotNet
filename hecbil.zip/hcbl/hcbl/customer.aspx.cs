﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Text;
using System.Configuration;
using System.Web.Security;

namespace hcbl
{
    public partial class WebForm8 : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {
             try
        {
            if (txtserviceid1.Text.Trim() == string.Empty)
            {
                lblError.Text = "Please input Username";
            }
            else if(txtpassword1.Text.Trim() == string.Empty)
            {
                lblError.Text = "Please input Password";
            }
            else
            {
                int flag = 0;
                SqlConnection con = new SqlConnection();
                con.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\sasi.smart\documents\visual studio 2010\Projects\hcbl\hcbl\App_Data\registration.mdf;Integrated Security=True;User Instance=True";
                con.Open();
                SqlCommand cmd = new SqlCommand("Validate_User", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@service_id", txtserviceid1.Text);
                cmd.Parameters.AddWithValue("@password", txtpassword1.Text);



                flag = Convert.ToInt32(cmd.ExecuteScalar());

                con.Close();
                switch (flag)
                {
                    case -1: lblError.Text = "Wrong Password";
                        break;
                    case 0: lblError.Text = "Entry doesnt exist";
                        break;
                    default: Session["Service_id"] = txtserviceid1.Text;
                        Response.Redirect("~/custlog.aspx");
                        break;
                        con.Open(); 
                            
                                                    

                            

                }
                
                
                
            }
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
        }
    }
        }
    }
