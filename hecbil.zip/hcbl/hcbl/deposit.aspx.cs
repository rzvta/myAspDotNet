﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace hcbl
{
    public partial class WebForm17 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_chec_Click(object sender, EventArgs e)
        {
            if (txtdeposit.Text != null)
            {
                lblcover.Text = "Your Security Cover Is";
                lblinterest.Text = "Your Interest Earned";
                lbltot.Text = "Total Value";
                double val = Convert.ToInt32(txtdeposit.Text);
                double cover = 1.1 * val;
                lblcoverval.Text = cover.ToString();
                double interest = 0.05* val;
                double tot_val = 1.05 * val;
                lblinterestval.Text = interest.ToString();
                lbltotval.Text = tot_val.ToString();

            }
        }
    }
}