﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace hcbl
{
    public partial class WebForm16 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Service_id"] != null)
            {

                txtserviceid.Text = Session["Service_id"].ToString();

            }
            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\sasi.smart\documents\visual studio 2010\Projects\hcbl\hcbl\App_Data\registration.mdf;Integrated Security=True;User Instance=True";
            con.Open();
            SqlCommand cmd1 = new SqlCommand("select service_id,choose_mnc,firstname,lastname,email_id,password,gender,dob,address,city,state,country,zip_code,phone,choose_plan,bank_name,branch_name,account_no,account_ho_name,uan,ifsc from registerTB where service_id=" + txtserviceid.Text, con);
            SqlDataReader dr = cmd1.ExecuteReader();
            dr.Read();

            if (dr.GetString(14) == "Deposit")
            {
                lblbnkname.Visible = false;
                lblbrnchname.Visible = false;
                lblaccno.Visible = false;
                lblacchoname.Visible = false;
                lbluan.Visible = false;
                lblifsc.Visible = false;

                dropdownbname.Visible = false;
                txtbrnchnaame.Visible = false;
                txtaccno.Visible =false;
                txtacchoname.Visible =false;
                txtuan.Visible =false;
                txtifsc.Visible = false;

            }
            //lblservicevalue.Text = dr.GetString(0);
            dropdwnmnc.SelectedItem.Value = dr.GetString(1);


            txtfirst.Text = dr.GetString(2);

            txtlast.Text = dr.GetString(3);


            txtemail.Text = dr.GetString(4);

            TextBox5.Text = dr.GetString(5);
            DropDownList1.SelectedItem.Value = dr.GetString(6);
            TextBox6.Text = dr.GetString(7);
            TextBox7.Text = dr.GetString(8);
            TextBox8.Text = dr.GetString(9);
            DropDownList3.SelectedItem.Value = dr.GetString(10);
            TextBox9.Text = dr.GetString(11);
            TextBox10.Text = dr.GetString(12);
            TextBox11.Text = dr.GetString(13);

            
            dropdownbname.SelectedItem.Value = dr.GetString(15);
            txtbrnchnaame.Text = dr.GetString(16);
            txtaccno.Text = dr.GetString(17);
            txtacchoname.Text = dr.GetString(18);
            txtuan.Text = dr.GetString(19);
            txtifsc.Text = dr.GetString(20);
            con.Close();
            
        }

        protected void btn_update_Click(object sender, EventArgs e)
        {
            string p;
            
            SqlConnection con1 = new SqlConnection();
            con1.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\sasi.smart\documents\visual studio 2010\Projects\hcbl\hcbl\App_Data\registration.mdf;Integrated Security=True;User Instance=True";
            con1.Open();
            SqlCommand cmd2 = new SqlCommand("select choose_plan from registerTB where service_id=" + txtserviceid.Text, con1);
            SqlDataReader dr1 = cmd2.ExecuteReader();
            dr1.Read();
            lbltrial.Text = dr1.GetString(0);
            con1.Close();
            if (TextBox5.Text != txtpassword.Text)
            {
                lblerror.Text = "Passwords do not match";
            }
            else
            {
                con1.Open();
                p = "delete from registerTB where service_id = " + txtserviceid.Text;
                SqlConnection con = new SqlConnection();
                con.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=c:\users\sasi.smart\documents\visual studio 2010\Projects\hcbl\hcbl\App_Data\registration.mdf;Integrated Security=True;User Instance=True";
                SqlCommand cmd = new SqlCommand(p, con1);
                cmd.ExecuteNonQuery();
                if (lbltrial.Text == "PF Account")
                {
                    
                    string q = "insert into registerTB(service_id,firstname,lastname,email_id,password,choose_mnc,gender,dob,address,city,state,country,zip_code,phone,bank_name,branch_name,account_no,account_ho_name,uan,ifsc,choose_plan)" + "values('" + txtserviceid.Text + "','" + txtfirst.Text + "','" + txtlast.Text + "','" + txtemail.Text + "','" + txtpassword.Text + "','" + dropdwnmnc.SelectedItem.Value + "','" + DropDownList1.SelectedItem.Value + "','" + TextBox6.Text + "','" + TextBox7.Text + "','" + TextBox8.Text + "','" + DropDownList3.SelectedItem.Value + "','" + TextBox9.Text + "','" + TextBox10.Text + "','" + TextBox11.Text + "','" + dropdownbname.SelectedItem.Value + "','" + txtbrnchnaame.Text + "','" + txtaccno.Text + "','" + txtacchoname.Text + "','" + txtuan.Text + "','" + txtifsc.Text + "'PF Account'" + "')";
                    SqlCommand cmd1 = new SqlCommand(q, con1);
                    cmd1.ExecuteNonQuery();
                }
                else
                {
                    
                    string r = "insert into registerTB(service_id,firstname,lastname,email_id,password,choose_mnc,gender,dob,address,city,state,country,zip_code,phone,bank_name,branch_name,account_no,account_ho_name,uan,ifsc,choose_plan)" + "values('" + txtserviceid.Text + "','" + txtfirst.Text + "','" + txtlast.Text + "','" + txtemail.Text + "','" + txtpassword.Text + "','" + dropdwnmnc.SelectedItem.Value + "','" + DropDownList1.SelectedItem.Value + "','" + TextBox6.Text + "','" + TextBox7.Text + "','" + TextBox8.Text + "','" + DropDownList3.SelectedItem.Value + "','" + TextBox9.Text + "','" + TextBox10.Text + "','" + TextBox11.Text + "','" + dropdownbname.SelectedItem.Value + "','" + txtbrnchnaame.Text + "','" + txtaccno.Text + "','" + txtacchoname.Text + "','" + txtuan.Text + "','" + txtifsc.Text + "'Deposit'" + "')";
                    SqlCommand cmd1 = new SqlCommand(r, con1);
                    cmd1.ExecuteNonQuery();
                }
                
                
                            
                
                con1.Close();
            }
            
        }
    }
}