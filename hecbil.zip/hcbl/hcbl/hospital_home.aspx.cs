﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace hcbl
{
    public partial class WebForm18 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_submit_Click(object sender, EventArgs e)
        {
            if (txtuname.Text.Trim() == string.Empty)
            {
                txtuname.Text = "Please Input First Name";
            }
            else if (txtserid.Text.Trim() == string.Empty)
            {
                txtserid.Text = "Please Input Service ID";
            }
            else
            {
                if (Session["hospital_id"] != null)
            {

                lblhosid.Text = Session["hospital_id"].ToString();

            }
                int flag = 0;
                SqlConnection con = new SqlConnection();
                con.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\sasi.smart\documents\visual studio 2010\Projects\hcbl\hcbl\App_Data\registration.mdf;Integrated Security=True;User Instance=True";
                con.Open();
                SqlCommand cmd = new SqlCommand("Validate_Patient", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@firstname", txtuname.Text);
                cmd.Parameters.AddWithValue("@service_id", txtserid.Text);



                flag = Convert.ToInt32(cmd.ExecuteScalar());

                con.Close();
                switch (flag)
                {
                    case 1: Session["hospital_id"] = lblhosid.Text;
                        Session["service_id"] = txtserid.Text;
                        Response.Redirect("patientdetails.aspx");
                        break;
                    case 0: lblerror.Text = "Patient Doesn't Exist";
                        break;


                }
            }
        }
    }
    }