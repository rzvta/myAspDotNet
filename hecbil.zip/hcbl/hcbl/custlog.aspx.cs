﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;


namespace hcbl
{
    public partial class WebForm7 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Service_id"] != null)
            {

                lblservicevalue.Text = Session["Service_id"].ToString();

            }

            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\sasi.smart\documents\visual studio 2010\Projects\hcbl\hcbl\App_Data\registration.mdf;Integrated Security=True;User Instance=True";
            con.Open();
            SqlCommand cmd1 = new SqlCommand("select service_id,choose_mnc,firstname,lastname,email_id,gender,dob,address,city,state,country,zip_code,phone,choose_plan,bank_name,branch_name,account_no,account_ho_name,uan,ifsc from registerTB where service_id=" + lblservicevalue.Text, con);
            SqlDataReader dr = cmd1.ExecuteReader();
            dr.Read();
            lblservicevalue.Text = dr.GetString(0);
            lblmncval.Text = dr.GetString(1);


            lblfnameval.Text = dr.GetString(2);

            lbllnameval.Text = dr.GetString(3);


            lblemailval.Text = dr.GetString(4);

            lblgenval.Text = dr.GetString(5);
            lbldobval.Text = dr.GetString(6);
            lbladdval.Text = dr.GetString(7);
            lblcityval.Text = dr.GetString(8);
            lblstateval.Text = dr.GetString(9);
            lblcountryval.Text = dr.GetString(10);
            lblzipval.Text = dr.GetString(11);
            lblphoneval.Text = dr.GetString(12);
            //lblplanval.Text = dr.GetString(13);

            if (dr.GetString(13) == "PF Account")
            {
                lblbnkname.Text = "Bank Name";
                lblbrnchname.Text = "Branch Name";
                lblaccno.Text = "Account No.";
                lblacchoname.Text = "Account Holder Name";
                lbluan.Text = "UAN";
                lblifsc.Text = "IFSC";

                lblbnkval.Text = dr.GetString(14);
                lblbrnchval.Text = dr.GetString(15);
                lblaccval.Text =dr.GetString(16);
                lblacchoval.Text = dr.GetString(17);
                lbluanval.Text = dr.GetString(18);
                lblifscval.Text = dr.GetString(19);
             }

            con.Close();
            Session["Service_id"] = lblservicevalue.Text;
           
        }

       
    }
}